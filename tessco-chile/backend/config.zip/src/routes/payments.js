const express = require('express');
const { PrismaClient } = require('@prisma/client');
const { MercadoPagoConfig, Preference, Payment } = require('mercadopago');
const { authenticateToken } = require('../middleware/auth');
const config = require('../config/app');
const emailService = require('../services/emailService');

const router = express.Router();
const prisma = new PrismaClient();

// Configuración de MercadoPago (usa variables de entorno)
const MERCADOPAGO_CONFIG = {
  accessToken: process.env.MERCADOPAGO_ACCESS_TOKEN || 'YOUR_MERCADOPAGO_ACCESS_TOKEN',
  publicKey: process.env.MERCADOPAGO_PUBLIC_KEY || 'YOUR_MERCADOPAGO_PUBLIC_KEY',
  webhookUrl: process.env.MERCADOPAGO_WEBHOOK_URL || `${config.apiBaseUrl}/api/payments/webhook`,
  webhookSecret: process.env.MERCADOPAGO_WEBHOOK_SECRET || null
};

let mercadoPagoClient = null;
let preferenceClient = null;
let paymentClient = null;

if (MERCADOPAGO_CONFIG.accessToken && MERCADOPAGO_CONFIG.accessToken !== 'YOUR_MERCADOPAGO_ACCESS_TOKEN') {
  mercadoPagoClient = new MercadoPagoConfig({
    accessToken: MERCADOPAGO_CONFIG.accessToken,
    options: {
      timeout: 10000,
      idempotencyKey: undefined
    }
  });
  preferenceClient = new Preference(mercadoPagoClient);
  paymentClient = new Payment(mercadoPagoClient);
} else {
  console.warn('⚠️ MercadoPago access token no configurado. La integración de pagos estará deshabilitada.');
}

const isTestMode = () => MERCADOPAGO_CONFIG.accessToken?.startsWith('TEST-');

// GET /api/payments/mercadopago/config - Obtener configuración pública
router.get('/mercadopago/config', authenticateToken, (req, res) => {
  if (!MERCADOPAGO_CONFIG.publicKey || MERCADOPAGO_CONFIG.publicKey === 'YOUR_MERCADOPAGO_PUBLIC_KEY') {
    return res.status(503).json({ error: 'MercadoPago no está configurado' });
  }

  res.json({
    publicKey: MERCADOPAGO_CONFIG.publicKey,
    mode: isTestMode() ? 'test' : 'production',
    locale: 'es-CL'
  });
});

// POST /api/payments/mercadopago/create - Crear preferencia de pago
router.post('/mercadopago/create', authenticateToken, async (req, res) => {
  try {
    if (!preferenceClient) {
      return res.status(503).json({ error: 'MercadoPago no está configurado' });
    }

    const { orderId } = req.body;

    if (!orderId) {
      return res.status(400).json({ error: 'ID de orden es requerido' });
    }

    // Obtener la orden
    const order = await prisma.order.findFirst({
      where: {
        id: orderId,
        userId: req.user.id
      },
      include: {
        items: {
          include: {
            product: true
          }
        },
        user: true
      }
    });

    if (!order) {
      return res.status(404).json({ error: 'Orden no encontrada' });
    }

    const shippingInfo = order.shippingAddress || {};
    const contactInfo = shippingInfo.contact || {};
    const addressInfo = shippingInfo.address || {};

    const payerName = `${contactInfo.firstName || ''} ${contactInfo.lastName || ''}`.trim() || `${order.user.firstName || ''} ${order.user.lastName || ''}`.trim();
    const payerEmail = contactInfo.email || order.user.email;
    const payerPhone = contactInfo.phone || order.user.phone || '';
    const sanitizedPhone = payerPhone ? payerPhone.replace(/\D/g, '').replace(/^56/, '') : '';

    const successUrl = `${config.frontendUrl}/checkout/success?orderId=${order.id}`;
    const failureUrl = `${config.frontendUrl}/checkout/failure?orderId=${order.id}`;
    const pendingUrl = `${config.frontendUrl}/checkout/pending?orderId=${order.id}`;

    // Crear preferencia de MercadoPago
    const preference = {
      items: order.items.map(item => ({
        title: item.product.name,
        quantity: item.quantity,
        unit_price: item.price,
        currency_id: 'CLP'
      })),
      payer: {
        name: payerName || undefined,
        email: payerEmail,
        phone: {
          area_code: '56',
          number: sanitizedPhone || undefined
        },
        address: {
          street_name: addressInfo.street || (shippingInfo.method === 'pickup' ? 'Retiro en tienda' : ''),
          zip_code: addressInfo.postalCode || '',
          city_name: addressInfo.comuna || addressInfo.city || '',
          state_name: addressInfo.region || ''
        }
      },
      back_urls: {
        success: successUrl,
        failure: failureUrl,
        pending: pendingUrl
      },
      auto_return: successUrl.startsWith('https://') ? 'approved' : undefined,
      external_reference: order.id,
      notification_url: `${config.apiBaseUrl}/api/payments/webhook`,
      shipments: shippingInfo.method === 'pickup' ? undefined : {
        mode: 'not_specified',
        cost: shippingInfo.cost || 0,
        receiver_address: {
          zip_code: addressInfo.postalCode || '',
          street_name: addressInfo.street || '',
          street_number: addressInfo.streetNumber || '',
          city_name: addressInfo.comuna || addressInfo.city || '',
          state_name: addressInfo.region || '',
          country_name: addressInfo.country || 'CL'
        }
      },
      metadata: {
        order_id: order.id,
        user_id: order.userId,
        shipping_method: shippingInfo.method || null
      },
      statement_descriptor: 'TESSCO CHILE',
      payment_methods: {
        excluded_payment_types: [
          { id: 'ticket' }
        ]
      }
    };

    const response = await preferenceClient.create({ body: preference });

    // Actualizar la orden con la preferencia de pago
    await prisma.order.update({
      where: { id: order.id },
      data: {
        paymentMethod: 'mercadopago',
        paymentStatus: 'pending'
      }
    });

    res.json({
      preferenceId: response.id,
      initPoint: response.init_point,
      sandboxInitPoint: response.sandbox_init_point,
      mode: isTestMode() ? 'test' : 'production',
      publicKey: MERCADOPAGO_CONFIG.publicKey
    });

  } catch (error) {
    console.error('Error creating MercadoPago preference:', error);
    res.status(500).json({ error: 'Error al crear la preferencia de pago' });
  }
});

// POST /api/payments/webhook - Webhook de MercadoPago
router.post('/webhook', async (req, res) => {
  try {
    if (!paymentClient) {
      console.warn('⚠️ Webhook recibido pero MercadoPago no está configurado.');
      return res.status(503).json({ error: 'MercadoPago no está configurado' });
    }

    const paymentId = req.body?.data?.id || req.query['data.id'] || req.body?.id;
    const topic = req.query.type || req.body.type || req.query.topic || req.body.topic;
    const action = req.body?.action || req.query.action || '';
    if (((topic && topic.includes('payment')) || (action && action.includes('payment'))) && paymentId) {
      const payment = await paymentClient.get({ id: paymentId });

      if (!payment || !payment.external_reference) {
        console.warn('⚠️ Pago recibido sin referencia externa', paymentId);
      } else {
        const orderId = payment.external_reference;
        const status = payment.status;

        const existingOrder = await prisma.order.findUnique({
          where: { id: orderId },
          include: {
            user: true,
            items: {
              include: {
                product: true
              }
            }
          }
        });

        if (!existingOrder) {
          console.warn(`⚠️ Orden ${orderId} no encontrada al procesar webhook.`);
          return res.status(200).json({ received: true });
        }

        const updateData = {
          paymentStatus: status === 'approved' ? 'paid' : status === 'rejected' ? 'failed' : 'pending'
        };

        if (status === 'approved') {
          updateData.status = 'confirmed';
        } else if (status === 'rejected') {
          updateData.status = 'cancelled';
        }

        try {
          const wasPaid = existingOrder.paymentStatus === 'paid';
          const updatedOrder = await prisma.order.update({
            where: { id: orderId },
            data: updateData,
            include: {
              user: true,
              items: {
                include: {
                  product: true
                }
              }
            }
          });

          if (status === 'approved' && !wasPaid) {
            await Promise.all([
              emailService.sendOrderConfirmationEmail(updatedOrder),
              emailService.sendOrderNotificationEmail(updatedOrder)
            ]);
          }
        } catch (updateError) {
          console.error(`❌ No se pudo actualizar la orden ${orderId}:`, updateError);
        }

        console.log(`✅ MercadoPago webhook procesado. Orden ${orderId} -> ${status}`);
      }
    }

    res.status(200).json({ received: true });
  } catch (error) {
    console.error('Error processing webhook:', error);
    res.status(500).json({ error: 'Error al procesar el webhook' });
  }
});

// GET /api/payments/status/:orderId - Verificar estado del pago
router.get('/status/:orderId', authenticateToken, async (req, res) => {
  try {
    const order = await prisma.order.findFirst({
      where: {
        id: req.params.orderId,
        userId: req.user.id
      },
      select: {
        id: true,
        status: true,
        paymentStatus: true,
        total: true,
        createdAt: true
      }
    });

    if (!order) {
      return res.status(404).json({ error: 'Orden no encontrada' });
    }

    res.json(order);
  } catch (error) {
    console.error('Error checking payment status:', error);
    res.status(500).json({ error: 'Error al verificar el estado del pago' });
  }
});

// POST /api/payments/bank-transfer - Procesar transferencia bancaria
router.post('/bank-transfer', authenticateToken, async (req, res) => {
  try {
    const { orderId } = req.body;

    if (!orderId) {
      return res.status(400).json({ error: 'ID de orden es requerido' });
    }

    // Obtener la orden
    const order = await prisma.order.findFirst({
      where: {
        id: orderId,
        userId: req.user.id
      },
      include: {
        items: {
          include: {
            product: true
          }
        }
      }
    });

    if (!order) {
      return res.status(404).json({ error: 'Orden no encontrada' });
    }

    // Generar instrucciones de transferencia bancaria
    const bankTransferInfo = {
      bankName: 'Banco de Chile',
      accountType: 'Cuenta Corriente',
      accountNumber: '12345678901',
      rut: '12.345.678-9',
      accountHolder: 'Tessco Chile SpA',
      amount: order.total,
      reference: `Orden ${order.id}`,
      instructions: [
        'Realiza la transferencia por el monto exacto indicado',
        'Usa el número de orden como referencia',
        'Envía el comprobante a contacto@tesscochile.cl',
        'Tu pedido será procesado una vez confirmado el pago'
      ]
    };

    res.json(bankTransferInfo);
  } catch (error) {
    console.error('Error processing bank transfer:', error);
    res.status(500).json({ error: 'Error al procesar la transferencia bancaria' });
  }
});

module.exports = router;