const express = require('express');
const { body, validationResult, query } = require('express-validator');
const { prisma } = require('../config/database');
const { authenticateToken } = require('../middleware/auth');
const multer = require('multer');
const sharp = require('sharp');
const path = require('path');
const fs = require('fs').promises;

const router = express.Router();

// Configurar multer para manejar multipart/form-data
const upload = multer();

// Función para procesar imágenes
async function processImages(files, productId) {
  const uploadDir = path.join(__dirname, '../../public/uploads/products');
  const productDir = path.join(uploadDir, productId);
  
  // Crear directorio del producto si no existe
  await fs.mkdir(productDir, { recursive: true });
  
  let imageUrl = null;
  let imageThumbnail = null;
  let images = [];
  let imageThumbnails = [];
  
  try {
    // Procesar imagen principal
    if (files.productImageFile && files.productImageFile[0]) {
      const mainImage = files.productImageFile[0];
      const mainImageName = `main-${Date.now()}.jpg`;
      const mainImagePath = path.join(productDir, mainImageName);
      
      // Redimensionar y guardar imagen principal
      await sharp(mainImage.buffer)
        .resize(800, 600, { fit: 'inside', withoutEnlargement: true })
        .jpeg({ quality: 90 })
        .toFile(mainImagePath);
      
      imageUrl = `/uploads/products/${productId}/${mainImageName}`;
      
      // Crear thumbnail
      const thumbnailName = `thumb-${mainImageName}`;
      const thumbnailPath = path.join(productDir, thumbnailName);
      
      await sharp(mainImage.buffer)
        .resize(200, 150, { fit: 'cover' })
        .jpeg({ quality: 80 })
        .toFile(thumbnailPath);
      
      imageThumbnail = `/uploads/products/${productId}/${thumbnailName}`;
    }
    
    // Procesar imágenes adicionales
    if (files.productImagesFiles && files.productImagesFiles.length > 0) {
      for (let i = 0; i < files.productImagesFiles.length; i++) {
        const additionalImage = files.productImagesFiles[i];
        const additionalImageName = `additional-${i}-${Date.now()}.jpg`;
        const additionalImagePath = path.join(productDir, additionalImageName);
        
        // Redimensionar y guardar imagen adicional
        await sharp(additionalImage.buffer)
          .resize(600, 400, { fit: 'inside', withoutEnlargement: true })
          .jpeg({ quality: 85 })
          .toFile(additionalImagePath);
        
        images.push(`/uploads/products/${productId}/${additionalImageName}`);
        
        // Crear thumbnail para imagen adicional
        const additionalThumbnailName = `thumb-additional-${i}-${Date.now()}.jpg`;
        const additionalThumbnailPath = path.join(productDir, additionalThumbnailName);
        
        await sharp(additionalImage.buffer)
          .resize(150, 100, { fit: 'cover' })
          .jpeg({ quality: 75 })
          .toFile(additionalThumbnailPath);
        
        imageThumbnails.push(`/uploads/products/${productId}/${additionalThumbnailName}`);
      }
    }
    
    return {
      imageUrl,
      imageThumbnail,
      images,
      imageThumbnails
    };
  } catch (error) {
    console.error('Error procesando imágenes:', error);
    return {
      imageUrl: null,
      imageThumbnail: null,
      images: [],
      imageThumbnails: []
    };
  }
}

// Middleware de debug para multer
const debugMulter = (req, res, next) => {
  console.log('🔧 Multer middleware ejecutándose...');
  console.log('🔧 Content-Type:', req.headers['content-type']);
  console.log('🔧 req.body antes de multer:', req.body);
  next();
};

// Validaciones
const productValidation = [
  body('name')
    .trim()
    .isLength({ min: 2, max: 200 })
    .withMessage('El nombre debe tener entre 2 y 200 caracteres'),
  body('description')
    .optional()
    .trim()
    .isLength({ max: 1000 })
    .withMessage('La descripción no puede exceder 1000 caracteres'),
  body('price')
    .isFloat({ min: 0 })
    .withMessage('El precio debe ser un número mayor o igual a 0'),
  body('stock')
    .optional()
    .isInt({ min: 0 })
    .withMessage('El stock debe ser un número entero mayor o igual a 0'),
  body('categoryId')
    .isString()
    .withMessage('categoryId es requerido'),
  body('brandName')
    .isString()
    .withMessage('brandName es requerido'),
  body('imageUrl')
    .optional()
    .isURL()
    .withMessage('Debe ser una URL válida'),
  body('images')
    .optional()
    .isArray()
    .withMessage('images debe ser un array'),
  body('isActive')
    .optional()
    .isBoolean()
    .withMessage('isActive debe ser un valor booleano')
];

// GET /api/products - Listar productos con filtros
router.get('/', [
  query('page').optional().isInt({ min: 1 }).withMessage('page debe ser un número entero mayor a 0'),
  query('limit').optional().isInt({ min: 1, max: 100 }).withMessage('limit debe ser un número entre 1 y 100'),
  query('category').optional().isString(),
  query('brand').optional().isString(),
  query('search').optional().isString(),
  query('minPrice').optional().isFloat({ min: 0 }),
  query('maxPrice').optional().isFloat({ min: 0 }),
  query('sort').optional().isIn(['name', 'price', 'createdAt']),
  query('order').optional().isIn(['asc', 'desc'])
], async (req, res) => {
  try {
    // Verificar errores de validación
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({
        success: false,
        message: 'Parámetros de consulta inválidos',
        errors: errors.array()
      });
    }

    const {
      page = 1,
      limit = 20,
      category,
      brand,
      search,
      minPrice,
      maxPrice,
      sort = 'createdAt',
      order = 'desc'
    } = req.query;

    const skip = (parseInt(page) - 1) * parseInt(limit);

    // Construir filtros
    const where = {
      isActive: true
    };

    if (category) {
      where.categoryId = category;
    }

    if (brand) {
      where.brandId = brand;
    }

    if (search) {
      where.OR = [
        { name: { contains: search, mode: 'insensitive' } },
        { description: { contains: search, mode: 'insensitive' } }
      ];
    }

    if (minPrice || maxPrice) {
      where.price = {};
      if (minPrice) where.price.gte = parseFloat(minPrice);
      if (maxPrice) where.price.lte = parseFloat(maxPrice);
    }

    // Ejecutar consulta
    const [products, totalCount] = await Promise.all([
      prisma.product.findMany({
        where,
        include: {
          category: {
            select: {
              id: true,
              name: true,
              slug: true
            }
          },
          brand: {
            select: {
              id: true,
              name: true,
              slug: true
            }
          }
        },
        orderBy: {
          [sort]: order
        },
        skip,
        take: parseInt(limit)
      }),
      prisma.product.count({ where })
    ]);

    const totalPages = Math.ceil(totalCount / parseInt(limit));

    res.json({
      success: true,
      data: products,
      pagination: {
        currentPage: parseInt(page),
        totalPages,
        totalCount,
        hasNextPage: parseInt(page) < totalPages,
        hasPreviousPage: parseInt(page) > 1
      }
    });

  } catch (error) {
    console.error('Error obteniendo productos:', error);
    res.status(500).json({
      success: false,
      message: 'Error interno del servidor'
    });
  }
});

// GET /api/products/:id - Obtener producto por ID
router.get('/:id', async (req, res) => {
  try {
    const { id } = req.params;
    
    const product = await prisma.product.findUnique({
      where: { id },
      include: {
        category: true,
        brand: true
      }
    });

    if (!product) {
      return res.status(404).json({
        success: false,
        message: 'Producto no encontrado'
      });
    }

    res.json({
      success: true,
      data: product
    });
  } catch (error) {
    console.error('Error obteniendo producto:', error);
    res.status(500).json({
      success: false,
      message: 'Error interno del servidor'
    });
  }
});

// POST /api/products - Crear nuevo producto
router.post('/', debugMulter, upload.fields([
  { name: 'productImageFile', maxCount: 1 },
  { name: 'productImagesFiles', maxCount: 5 }
]), authenticateToken, async (req, res) => {
  try {
    console.log('🔧 Después de multer:');
    console.log('🔧 req.body:', req.body);
    console.log('🔧 req.files:', req.files);
    
    // Verificar que el usuario sea admin
    if (req.user.role !== 'admin') {
      return res.status(403).json({
        success: false,
        message: 'No tienes permisos para realizar esta acción'
      });
    }

    const { name, description, price, stock = 0, categoryId, brandName, brandId, imageUrl, images = [], isActive = 'true' } = req.body;
    
    // Convertir strings a tipos correctos
    const productData = {
      name: name.trim(),
      description: description ? description.trim() : null,
      price: parseFloat(price),
      stock: parseInt(stock) || 0,
      categoryId: categoryId.trim(),
      brandName: brandName.trim(),
      isActive: isActive === 'true' || isActive === true
    };
    
    console.log('🔍 Datos recibidos en el backend (después de multer):');
    console.log('🔍 categoryId:', categoryId);
    console.log('🔍 brandName:', brandName);
    console.log('🔍 req.body completo:', req.body);
    console.log('🔍 req.files:', req.files);
    
    // Validar campos requeridos
    if (!productData.name || !productData.categoryId || !productData.brandName || !productData.price) {
      return res.status(400).json({
        success: false,
        message: 'Datos de entrada inválidos',
        errors: [
          ...(!productData.name ? [{ field: 'name', message: 'El nombre es requerido' }] : []),
          ...(!productData.categoryId ? [{ field: 'categoryId', message: 'La categoría es requerida' }] : []),
          ...(!productData.brandName ? [{ field: 'brandName', message: 'La marca es requerida' }] : []),
          ...(!productData.price ? [{ field: 'price', message: 'El precio es requerido' }] : [])
        ]
      });
    }

    // Verificar que la categoría exista
    const category = await prisma.category.findUnique({ where: { id: productData.categoryId } });
    if (!category) {
      return res.status(400).json({
        success: false,
        message: 'Categoría no encontrada'
      });
    }

    // Manejar la marca: crear automáticamente si se proporciona brandName
    let brand;
    console.log('🔍 Verificando brandName:', productData.brandName);
    
    if (productData.brandName) {
      // Buscar marca existente por nombre
      brand = await prisma.brand.findFirst({ 
        where: { 
          name: { 
            equals: productData.brandName, 
            mode: 'insensitive' 
          } 
        } 
      });
      
      console.log('🔍 Marca encontrada:', brand);
      
      // Si no existe, crear nueva marca
      if (!brand) {
        const slug = productData.brandName
          .toLowerCase()
          .replace(/[^a-z0-9\s-]/g, '')
          .replace(/\s+/g, '-')
          .replace(/-+/g, '-')
          .trim();
        
        console.log('🔍 Creando nueva marca con slug:', slug);
        
        brand = await prisma.brand.create({
          data: {
            name: productData.brandName,
            slug: slug,
            isActive: true
          }
        });
        
        console.log('🔍 Marca creada:', brand);
      }
    } else if (brandId) {
      // Buscar marca por ID (para compatibilidad con edición)
      brand = await prisma.brand.findUnique({ where: { id: brandId } });
      if (!brand) {
        return res.status(400).json({
          success: false,
          message: 'Marca no encontrada'
        });
      }
    } else {
      return res.status(400).json({
        success: false,
        message: 'Se debe proporcionar el nombre de la marca'
      });
    }

    // Crear el producto primero para obtener el ID
    const product = await prisma.product.create({
      data: {
        name: productData.name,
        description: productData.description,
        price: productData.price,
        stock: productData.stock,
        categoryId: productData.categoryId,
        brandId: brand.id,
        imageUrl: null, // Temporalmente null
        imageThumbnail: null,
        images: [],
        imageThumbnails: [],
        isActive: productData.isActive
      },
      include: {
        category: {
          select: {
            id: true,
            name: true,
            slug: true
          }
        },
        brand: {
          select: {
            id: true,
            name: true,
            slug: true
          }
        }
      }
    });

    // Procesar imágenes si existen
    console.log('🔍 Procesando imágenes...');
    const imageData = await processImages(req.files, product.id);
    
    console.log('🔍 Datos de imagen procesados:', imageData);

    // Actualizar el producto con las URLs de las imágenes
    if (imageData.imageUrl || imageData.images.length > 0) {
      await prisma.product.update({
        where: { id: product.id },
        data: {
          imageUrl: imageData.imageUrl,
          imageThumbnail: imageData.imageThumbnail,
          images: imageData.images,
          imageThumbnails: imageData.imageThumbnails
        }
      });
    }

    // Obtener el producto actualizado con las imágenes
    const updatedProduct = await prisma.product.findUnique({
      where: { id: product.id },
      include: {
        category: {
          select: {
            id: true,
            name: true,
            slug: true
          }
        },
        brand: {
          select: {
            id: true,
            name: true,
            slug: true
          }
        }
      }
    });

    res.status(201).json({
      success: true,
      message: 'Producto creado exitosamente',
      data: updatedProduct
    });

  } catch (error) {
    console.error('Error creando producto:', error);
    res.status(500).json({
      success: false,
      message: 'Error interno del servidor'
    });
  }
});

// PUT /api/products/:id - Actualizar producto
router.put('/:id', upload.fields([
  { name: 'productImageFile', maxCount: 1 },
  { name: 'productImagesFiles', maxCount: 5 }
]), authenticateToken, async (req, res) => {
  try {
    console.log('🔧 Después de multer (PUT):');
    console.log('🔧 req.body:', req.body);
    console.log('🔧 req.files:', req.files);
    
    const { name, description, price, stock = 0, categoryId, brandName, brandId, imageUrl, images = [], isActive = 'true' } = req.body;
    
    // Convertir strings a tipos correctos
    const productData = {
      name: name ? name.trim() : null,
      description: description ? description.trim() : null,
      price: price ? parseFloat(price) : null,
      stock: stock ? parseInt(stock) : null,
      categoryId: categoryId ? categoryId.trim() : null,
      brandName: brandName ? brandName.trim() : null,
      isActive: isActive === 'true' || isActive === true
    };
    
    // Validar campos requeridos
    if (!productData.name || !productData.categoryId || !productData.brandName || !productData.price) {
      return res.status(400).json({
        success: false,
        message: 'Datos de entrada inválidos',
        errors: [
          ...(!productData.name ? [{ field: 'name', message: 'El nombre es requerido' }] : []),
          ...(!productData.categoryId ? [{ field: 'categoryId', message: 'La categoría es requerida' }] : []),
          ...(!productData.brandName ? [{ field: 'brandName', message: 'La marca es requerida' }] : []),
          ...(!productData.price ? [{ field: 'price', message: 'El precio es requerido' }] : [])
        ]
      });
    }

    // Verificar que el usuario sea admin
    if (req.user.role !== 'admin') {
      return res.status(403).json({
        success: false,
        message: 'No tienes permisos para realizar esta acción'
      });
    }

    const { id } = req.params;

    // Verificar si el producto existe
    const existingProduct = await prisma.product.findUnique({
      where: { id }
    });

    if (!existingProduct) {
      return res.status(404).json({
        success: false,
        message: 'Producto no encontrado'
      });
    }

    // Verificar que la categoría exista si se proporciona
    if (categoryId) {
      const category = await prisma.category.findUnique({ where: { id: categoryId } });
      if (!category) {
        return res.status(400).json({
          success: false,
          message: 'Categoría no encontrada'
        });
      }
    }

    // Manejar la marca: crear automáticamente si se proporciona brandName
    let brand;
    console.log('🔍 Verificando brandName (PUT):', productData.brandName);
    
    if (productData.brandName) {
      // Buscar marca existente por nombre
      brand = await prisma.brand.findFirst({ 
        where: { 
          name: { 
            equals: productData.brandName, 
            mode: 'insensitive' 
          } 
        } 
      });
      
      console.log('🔍 Marca encontrada (PUT):', brand);
      
      // Si no existe, crear nueva marca
      if (!brand) {
        const slug = productData.brandName
          .toLowerCase()
          .replace(/[^a-z0-9\s-]/g, '')
          .replace(/\s+/g, '-')
          .replace(/-+/g, '-')
          .trim();
        
        console.log('🔍 Creando nueva marca con slug (PUT):', slug);
        
        brand = await prisma.brand.create({
          data: {
            name: productData.brandName,
            slug: slug,
            isActive: true
          }
        });
      }
    } else if (brandId) {
      // Buscar marca por ID (para compatibilidad)
      brand = await prisma.brand.findUnique({ where: { id: brandId } });
      if (!brand) {
        return res.status(400).json({
          success: false,
          message: 'Marca no encontrada'
        });
      }
    }

    const updateData = {
      name: productData.name,
      description: productData.description,
      price: productData.price,
      stock: productData.stock,
      categoryId: productData.categoryId,
      brandId: brand.id, // Usar el ID de la marca encontrada o creada
      isActive: productData.isActive
    };
    
    console.log('🔍 Actualizando producto con datos:', updateData);

    // Procesar imágenes si existen
    console.log('🔍 Procesando imágenes (PUT)...');
    const imageData = await processImages(req.files, id);
    
    console.log('🔍 Datos de imagen procesados (PUT):', imageData);

    // Agregar datos de imagen al updateData si existen
    if (imageData.imageUrl || imageData.images.length > 0) {
      updateData.imageUrl = imageData.imageUrl;
      updateData.imageThumbnail = imageData.imageThumbnail;
      updateData.images = imageData.images;
      updateData.imageThumbnails = imageData.imageThumbnails;
    }

    const product = await prisma.product.update({
      where: { id },
      data: updateData,
      include: {
        category: {
          select: {
            id: true,
            name: true,
            slug: true
          }
        },
        brand: {
          select: {
            id: true,
            name: true,
            slug: true
          }
        }
      }
    });

    res.json({
      success: true,
      message: 'Producto actualizado exitosamente',
      data: product
    });

  } catch (error) {
    console.error('Error actualizando producto:', error);
    res.status(500).json({
      success: false,
      message: 'Error interno del servidor'
    });
  }
});

// DELETE /api/products/:id - Eliminar producto
router.delete('/:id', authenticateToken, async (req, res) => {
  try {
    // Verificar que el usuario sea admin
    if (req.user.role !== 'admin') {
      return res.status(403).json({
        success: false,
        message: 'No tienes permisos para realizar esta acción'
      });
    }

    const { id } = req.params;

    // Verificar si el producto existe
    const existingProduct = await prisma.product.findUnique({
      where: { id },
      include: {
        orderItems: {
          select: {
            id: true
          }
        }
      }
    });

    if (!existingProduct) {
      return res.status(404).json({
        success: false,
        message: 'Producto no encontrado'
      });
    }

    // Verificar si tiene órdenes asociadas
    if (existingProduct.orderItems.length > 0) {
      return res.status(409).json({
        success: false,
        message: 'No se puede eliminar un producto que tiene órdenes asociadas'
      });
    }

    await prisma.product.delete({
      where: { id }
    });

    res.json({
      success: true,
      message: 'Producto eliminado exitosamente'
    });

  } catch (error) {
    console.error('Error eliminando producto:', error);
    res.status(500).json({
      success: false,
      message: 'Error interno del servidor'
    });
  }
});

module.exports = router;
